﻿namespace RazorAdvance.Models
{
    public class Category
    {
        public string Name { get; set; } = string.Empty;
    }
}
